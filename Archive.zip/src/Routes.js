import React, { Component } from 'react';

import { StackNavigator, DrawerNavigator } from 'react-navigation';
import Auth from '../src/Components/Auth/AuthNavigationConfiguration';
import Dashboard from '../src/Components/Dashboard/DashboardNavigationConfiguration';
import AssetList from '../src/Components/List/ListNavigationConfiguration';
import CreateAsset from '../src/Components/CreateAsset/CreateNavigationConfiguration';
import SidebarScreens from '../src/Components/SidebarScreens/SidebarNavigationConfiguration';
import FilterScreen from '../src/Components/Filers/FilterNavigationConfig';
import Configuration from '../src/Components/Filers/View/Configuration';
import Filter from '../src/Components/Filers/View/Filter';

import Sidebar from '../src/Components/Sidebar'
// Drawer navigator
const DrawerNav = DrawerNavigator({
    Dashboard: { screen: Dashboard },
    AssetList: { screen: AssetList },
    CreateAsset: { screen: CreateAsset },
    SidebarScreens : {screen : SidebarScreens},
    FilterScreen : {screen : FilterScreen},
 

},
    {
        initialRouteName: 'Dashboard',
        headerMode: 'none',
        drawerBackgroundColor: '#5A6B71',
        contentComponent: Sidebar,
        navigationOptions: {
            gesturesEnabled: false,
        }
        

          
    },


)

// route navigator
const Routes = StackNavigator({
    Auth: { screen: Auth, },
    DrawerNav: { screen: DrawerNav, },


}, {
        initialRouteName: 'Auth',
        headerMode: 'none',
        navigationOptions: {
            gesturesEnabled: false,
        }
       
          

    })



export default Routes;