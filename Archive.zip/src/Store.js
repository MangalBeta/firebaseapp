import { createStore, applyMiddleware, compose } from "redux";
import thunk from "redux-thunk";
import rootReducer from "./Reducers";

// a function which can create our store 
export default (initialState = {}) => {
    // ======================================================
    // Middleware Configuration
    const middleware = [thunk];
    // ======================================================
    // Store Enhancers
    const enhancers = [];
    // Store Instantiation
    // ======================================================
    const store = createStore(
        rootReducer(),
        initialState,
        compose(
            applyMiddleware(...middleware),
            ...enhancers
        )
    );
    return store;
};