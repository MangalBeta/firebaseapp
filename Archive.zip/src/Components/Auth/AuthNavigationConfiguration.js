import React, { Component } from 'react';

import { StackNavigator } from 'react-navigation';

// import  component 
import Login from './View/Login';
import ForgotPassword from './View/ForgotPassword';

// Auth navigator
const AuthNavigator = StackNavigator({
        Login: { screen: Login },
        ForgotPassword: { screen: ForgotPassword },


}, 
{
        initialRouteName: 'Login',
        headerMode: 'none'

    })



export default AuthNavigator;