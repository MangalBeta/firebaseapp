import React, { Component } from 'react';
import { View, Text, Image, StyleSheet,KeyboardAvoidingView } from 'react-native';
import LoginForm from '../Templates/LoginForm';
import AppLogo from '../../../Assets/logo4x.png'

// create a component
class Login extends Component {
    render() {
        return (
        <KeyboardAvoidingView behavior="padding" style={styles.container}>

            <View style={styles.loginContainer}>
                    <Image resizeMode="contain" style={styles.logo} 
                    source={AppLogo} />
                    </View>
               <View style={styles.formContainer}>
                   <LoginForm navigate={this.props.navigation.navigate}/>
               </View>
               <View style={styles.bottomContainer}>
               <Text style={styles.bottomText}> 2018 ORDITAL PTY LTD,All Rights Reserved</Text>
               </View>
         
            </KeyboardAvoidingView>
        );
    }
}

// define your styles
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#FAFAFA',
    },
    loginContainer:{
        alignItems: 'center',
        flexGrow: 1,
        justifyContent: 'center'
    },
 
    title:{
        color: "#FFF",
        marginTop: 120,
        width: 180,
        textAlign: 'center',
        opacity: 0.9
    },
    formContainer :{
      justifyContent:'flex-start',
      flex:5
    },
    bottomContainer:{
      justifyContent:'flex-end',
      alignItems:'center',
      flex:0.5,
      paddingVertical:10
    },
    bottomText: {
      fontSize:14,
      fontWeight:'bold'
    }
});

//make this component available to the app
export default Login;
