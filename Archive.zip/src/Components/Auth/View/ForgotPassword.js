import React, { Component } from 'react';
import { View, StatusBar,Dimensions, Text, Image, StyleSheet, KeyboardAvoidingView } from 'react-native';
import LoginForm from '../Templates/LoginForm';
import AppLogo from '../../../Assets/logo4x.png'
import { CheckBox } from 'react-native-elements'
import { Button } from 'react-native-elements';

const { width, height } = Dimensions.get('window')
// create a component
class ForgotPassword extends Component {
    constructor(props) {
        super(props)
        this.state = {
            checked1: false,
            check2: false
        }
    }
    render() {
        return (
            <KeyboardAvoidingView behavior="padding" style={styles.container}>

                <View style={styles.loginContainer}>
                    <Image resizeMode="contain" style={styles.logo}
                        source={AppLogo} />
                </View>
                <View style={styles.formContainer}>
                    <CheckBox
                        onPress={() => this.setState({ checked1: !this.state.checked1 })}
                        containerStyle={{
                            paddingLeft: 35,
                            alignSelf: 'center',
                            borderWidth: 0, borderRadius: 0,
                        }}
                        textStyle={{
                            fontSize: 14,
                            color: 'black',
                            fontWeight: 'bold'
                        }}
                        title=' Reset Password Via Text/SMS'
                        checkedColor={'black'}
                        checked={this.state.checked1} />
                    <CheckBox
                        onPress={() => this.setState({ checked2: !this.state.checked2 })}
                        containerStyle={{ borderWidth: 0, borderRadius: 0, }}
                        textStyle={{
                            fontSize: 14,
                            color: 'black',
                            fontWeight: 'bold'
                        }}
                        title=' Reset Password Via Email'
                        checkedColor={'black'}
                        checked={this.state.checked2} />

                </View>
                <View style={{ flex: 6 }}>
                    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                        <Button
                            title="Reset Password"
                            titleStyle={{ fontWeight: "700",fontSize:22, color: 'black' }}
                            buttonStyle={{
                                backgroundColor: "#E69138",
                                width: width - 60,
                                height: 45,
                                borderColor: "black",
                                borderWidth: 2,
                                borderRadius: 2,
                                shadowOffset: { width: 10, height: 10, },
                                shadowColor: 'black',
                                shadowOpacity: 0.4,
                                elevation:5
                            }}
                            containerStyle={{ marginTop: 20 }}
                        />
                    </View>
                    <View style={{ flex: 4, justifyContent: 'flex-start', alignItems: 'center' }}>

                        <Button
                            title="Cancel"
                            onPress={() => this.props.navigation.goBack()}
                            titleStyle={{ color: 'red' }}
                            buttonStyle={{
                                backgroundColor: "#E69138",
                                width: width - 60,
                                height: 45,
                                borderColor: "black",
                                borderWidth: 2,
                                borderRadius: 2,
                                shadowOffset: { width: 10, height: 10, },
                                shadowColor: 'black',
                                shadowOpacity: 0.4,
                                elevation:5

                            }}
                            containerStyle={{ marginTop: 20 }}
                        />
                    </View>

                </View>
                <View style={styles.bottomContainer}>
                    <Text style={styles.bottomText}> 2018 ORDITAL PTY LTD,All Rights Reserved</Text>
                </View>

            </KeyboardAvoidingView>
        );
    }
}

// define your styles
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#FAFAFA',
    },
    loginContainer: {
        alignItems: 'center',
        flexGrow: 1,
        justifyContent: 'center'
    },

    title: {
        color: "#FFF",
        marginTop: 120,
        width: 180,
        textAlign: 'center',
        opacity: 0.9
    },
    formContainer: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flex: 2,
        marginTop:20
        // marginLeft: width / 6,
    },
    bottomContainer: {
        justifyContent: 'flex-end',
        alignItems: 'center',
        flex: 0.5,
        paddingVertical: 10
    },
    bottomText: {
        fontSize: 14,
        fontWeight: 'bold'
    }
});

//make this component available to the app
export default ForgotPassword;
