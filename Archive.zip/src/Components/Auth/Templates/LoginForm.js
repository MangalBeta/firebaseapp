//import liraries
import React, { Component } from 'react';
import { StackNavigator } from 'react-navigation';

import { View, Text, TextInput, TouchableOpacity, Alert, Button, StyleSheet, StatusBar } from 'react-native';

import { CheckBox } from 'react-native-elements'

// create a component
class LoginForm extends Component {
    constructor(props) {
        super(props)
        this.state = {
            checked: false
        }
    }
    onButtonPress() {
        this.props.navigate('Dashboard')
    };

    render() {
        return (
            <View style={styles.container}>
                <StatusBar

                    barStyle="dark-content"

                />
                <View style={styles.inputView}>
                    <Text style={styles.label}> Username</Text>
                    <TextInput style={styles.input}
                        autoCapitalize="none"
                        onSubmitEditing={() => this.passwordInput.focus()}
                        autoCorrect={false}
                        returnKeyType="next"
                        placeholder='username'
                        placeholderTextColor='rgba(225,225,225,0.7)' />
                </View>
                <View style={styles.inputView}>

                    <Text style={styles.label}> Password</Text>

                    <TextInput style={styles.input}
                        returnKeyType="go" ref={(input) => this.passwordInput = input}
                        placeholder='Password'
                        placeholderTextColor='rgba(225,225,225,0.7)'
                        secureTextEntry />
                </View>

                <TouchableOpacity style={styles.buttonContainer} onPress={this.onButtonPress.bind(this)}>
                    <Text style={styles.buttonText}>LOG IN</Text>
                </TouchableOpacity>
                <View style={{
                    flexDirection: 'row',
                    paddingVertical: 16,
                    justifyContent: 'space-between'
                }}>
                    <CheckBox
                        onPress={() => this.setState({ checked: !this.state.checked })}
                        containerStyle={{ borderWidth: 0, borderRadius: 0 }}
                        textStyle={{
                            fontSize: 14,
                            color: 'black',
                            fontWeight: 'bold'
                        }}
                        title=' Remember me'
                        checkedColor={'black'}
                        checked={this.state.checked} />


                    <TouchableOpacity style={{alignItems:'center',justifyContent:'center'}} onPress={() => this.props.navigate('ForgotPassword')}>
                        <Text style={styles.textstyle}>Forgot Password</Text>
                    </TouchableOpacity>

                </View>
            </View>
        );
    }
}

// define your styles
const styles = StyleSheet.create({
    container: {
        paddingHorizontal: 20,
        justifyContent: 'flex-start'
    },
    input: {
        backgroundColor: '#fff',
        marginBottom: 10,
        padding: 10,
        borderColor: '#000',
        borderWidth: 2

    },
    inputView: {
        paddingVertical: 5

    },
    textstyle: {
        fontSize: 14,
        fontWeight: 'bold',
    },

    buttonContainer: {
        backgroundColor: '#AAAAAA',
        paddingVertical: 15,
        marginTop: 10,

    },
    buttonText: {
        color: '#fff',
        textAlign: 'center',
        fontWeight: '700'
    },
    loginButton: {
        backgroundColor: '#2980b6',
        color: '#fff'
    },
    label: { fontSize: 14, paddingBottom: 10 }



});

//make this component available to the app
export default LoginForm;