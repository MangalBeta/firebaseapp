import React, { Component } from 'react';
import {
    View, Text, Image, FlatList, TouchableOpacity, Dimensions, ScrollView, Button, StyleSheet,
    KeyboardAvoidingView
} from 'react-native';
const { width, height } = Dimensions.get('window')
import Icon from 'react-native-vector-icons/FontAwesome'

import { StackNavigator, DrawerNavigator } from 'react-navigation';
// Import Images
import AppLogo from '../../../Assets/logo4x.png'
import MenuBar from '../../../Assets/menubar.png'
import ListTab from '../../../Assets/listtab2x.png'
import FindTab from '../../../Assets/findtab2x.png'
import CreateTab from '../../../Assets/createtab2x.png'
import UploadImg from '../../../Assets/assetDemo.jpg'
import RefreshImg from '../../../Assets/refresh-48.png'
import CheckImg from '../../../Assets/check-48.png'
import ListImg from '../../../Assets/menu-o-2-48.png'
import WhiteRefreshImg from '../../../Assets/whiterefresh2-48.png'
import WhiteCheckImg from '../../../Assets/white-check-48.png'
import WhiteListImg from '../../../Assets/white-menu-2-48.png'
//Import component
import Header from '../../Common/Header'
// create a component
let data = [
    {
        heading: "SP 168-B-TR1-1 dsdf sdgdsg ", detail: 'HANNANT A PROP TR/17/06/2017  11:06 AM', info: " ",
        image: <Image source={UploadImg}
            style={{ alignSelf: 'center', height: 150, width: 140 }}
            resizeMode="contain" />
    },
    { heading: "SSQPT-VT11-1", info: "TR-VT,33" },
    {
        heading: "ASSET_2017", detail: 'HANNANT A PROP TR/17/06/2017  11:06 AM', info: " ", image: <Image source={UploadImg}
            style={{ alignSelf: 'center', height: 150, width: 140 }}
            resizeMode="contain" />
    },
    { heading: "ASSET_201710901_624556174", info: "des" },
    {
        heading: "assetToday28august2017", detail: 'HANNANT A PROP TR/17/06/2017  11:06 AM', info: " ", image: <Image source={UploadImg}
            style={{ alignSelf: 'center', height: 150, width: 140 }}
            resizeMode="contain" />
    },
    { heading: "ASSET_20171009_252229570", info: " " },
    { heading: "ASSET_20171005_25266855", info: " " },
    {
        heading: "ASSET_2017", detail: 'HANNANT A PROP TR/17/06/2017  11:06 AM', info: " ",
        image: <Image source={UploadImg}
            style={{ alignSelf: 'center', height: 150, width: 140 }}
            resizeMode="contain" />
    },
    { heading: "ASSET_201710901_624556174", info: "des" },
    { heading: "assetToday28august2017", info: "morning" },
    {
        heading: "ASSET_20171009_252229570", detail: 'HANNANT A PROP TR/17/06/2017  11:06 AM', info: " ", image: <Image source={UploadImg}
            style={{ alignSelf: 'center', height: 150, width: 140 }}
            resizeMode="contain" />
    },
    { heading: "ASSET_20171005_25266855", info: " " },
    {
        heading: "ASSET_2017", detail: 'HANNANT A PROP TR/17/06/2017  11:06 AM', info: " ", image: <Image source={UploadImg}
            style={{ alignSelf: 'center', height: 150, width: 140 }}
            resizeMode="contain" />
    },
    { heading: "ASSET_201710901_624556174", info: "des" },
    { heading: "assetToday28august2017", info: "morning" },
    {
        heading: "ASSET_20171009_252229570", detail: 'HANNANT A PROP TR/17/06/2017  11:06 AM', info: " ", image: <Image source={UploadImg}
            style={{ alignSelf: 'center', height: 150, width: 140 }}
            resizeMode="contain" />
    },
    { heading: "ASSET_20171005_25266855", info: " " },
    {
        heading: "ASSET_2017", detail: 'HANNANT A PROP TR/17/06/2017  11:06 AM', info: " ", image: <Image source={UploadImg}
            style={{ alignSelf: 'center', height: 150, width: 140 }}
            resizeMode="contain" />
    },
    { heading: "ASSET_201710901_624556174", info: "des" },
    { heading: "assetToday28august2017", info: "morning" },
]
const TabsArr = [ListImg, CheckImg, RefreshImg]
class AssetList extends Component {
    static navigationOptions = ({ navigation }) => ({
        title: ``,
    });
    constructor() {
        super();
        this.state = {
            checked: false,
            indexItem: -1,
            active: false
        }
    }
    openDrawer() {
        this.props.navigate('DrawerOpen')
    }
    renderTabView() {
        return TabsArr.map((tabImg, index) => {
            return (

                <View style={styles.tabview} key={index}>
                    <TouchableOpacity onPress={() => this.setState({
                        indexItem: index,
                    })}>
                        {this.state.indexItem == index ?
                            <View>
                                {
                                    (this.state.indexItem == 0) ? <Image source={WhiteListImg}
                                        style={{ width: 36, height: 36, alignSelf: 'center' }}
                                        resizeMode="contain" /> : null
                                }
                                {
                                    (this.state.indexItem == 1) ? <Image source={WhiteCheckImg}
                                        style={{ width: 36, height: 36, alignSelf: 'center' }}
                                        resizeMode="contain" /> : null
                                }
                                {
                                    (this.state.indexItem == 2) ? <Image source={WhiteRefreshImg}
                                        style={{ width: 36, height: 36, alignSelf: 'center' }}
                                        resizeMode="contain" /> : null
                                }
                            </View>

                            : <Image source={tabImg}
                                style={{ width: 36, height: 36, alignSelf: 'center' }}
                                resizeMode="contain" />
                        }

                    </TouchableOpacity >

                </View>

            )
        })
    }
    _renderItem = ({ item, index }) => {
        return (
            <TouchableOpacity onPress={() => this.props.navigation.navigate('ListDetail')}>
                <View style={{
                    flex: 1,
                    borderColor: '#50575D',
                    borderWidth: 1,
                    // borderRadius:5,
                    marginBottom: 10, backgroundColor: '#FFF',

                }}>
                    <View style={{
                        flex: 1, borderWidth: 1, borderColor: '#50575D',
                        // borderRadius:10,
                        padding: 10, flexDirection: 'row'
                    }}>
                        {
                            (item.image) ?
                                <View style={{ flex: 1, flexDirection: 'row', }}>
                                    <View style={{ flex: 1, marginLeft: 40 }}>
                                        {item.image}
                                    </View>
                                    <View style={{ flex: 3, marginLeft: 40, justifyContent: 'flex-start', alignItems: 'center' }}>
                                        <Text style={{
                                            color: '#524b48', fontSize: 22,
                                            fontFamily: 'Helvetica Neue',
                                            fontWeight:'bold',

                                            marginBottom: 5
                                        }}>{item.heading}</Text>
                                        <Text style={{
                                            color: '#777', fontSize: 18, fontFamily: 'Helvetica Neue',
                                        }}>{item.detail}</Text>
                                    </View>
                                </View> :
                                <View style={{ flex: 1, }}>
                                    <Text style={{ color: '#524b48', 
                                    fontFamily: 'Helvetica Neue',
                                    fontWeight:'bold',
                                     fontSize: 22, marginBottom: 5 }}>{item.heading}</Text>
                                    <Text style={{ color: '#6E7377', 
                                    fontFamily: 'Helvetica Neue', fontSize: 18 }}>{item.info}</Text>
                                </View>
                        }

                    </View>
                </View>
            </TouchableOpacity>
        )

    }
    _keyExtractor = (item, index) => index + 'assets';
    render() {
        return (
            <View style={{ flex: 1 }}>
                <Header
                    rightIcon='map'
                    leftIcon='home'
                    color={'#fff'}
                    goBack={this.props.navigation.goBack}
                    sidebar={true}
                    openScreen={() => console.log()}
                    navigateClick={() => this.props.navigation.navigate('Dashboard')}
                />
                <View style={styles.container}>
                    <FlatList
                        data={data}
                        keyExtractor={this._keyExtractor}
                        style={{ flex: 1, width: width, padding: 10 }}
                        renderItem={this._renderItem}
                    />
                </View>
                <View style={styles.cardView4}>

                    {this.renderTabView()}

                </View>
            </View>
        );
    }
}

// define your styles
const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#FBFBFB',
        paddingBottom: 80
    },
    tabview: { flex: 1 },
    mainView: {
        flex: 1,
        paddingHorizontal: 20,
        paddingVertical: 10
        // paddingVertical:20
    },
    image: { width: width - 40, height: height / 4 },
    cardView1: {
        flex: 1,

        // backgroundColor:'#FF6F20',
        // height:height/4,
    },
    cardView2: {
        // backgroundColor:'#5A6B71',        
        // height:height/4,
        flex: 1,

    },
    cardView3: {
        flex: 1,

        // backgroundColor:'#F15B4E',
        // height:height/4,


    },
    cardView4: {
        position: 'absolute',
        bottom: 0, left: 0, right: 0, height: 75,
        // render global persistent stuff here 
        backgroundColor: '#524b48',
        flexDirection: 'row',
        // flex:-1,
        justifyContent: 'center',
        alignItems: 'center',

    },
    tabText: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#fff',
        alignSelf: 'center'
    }
});

//make this component available to the app
export default AssetList;
