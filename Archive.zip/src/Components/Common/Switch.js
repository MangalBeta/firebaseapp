import React, { Component } from 'react';
import {
    View, Text, TextInput, Image, Dimensions, ScrollView, StyleSheet,
    KeyboardAvoidingView, Switch
} from 'react-native';
const { width, height } = Dimensions.get('window')
// import { StackNavigator, DrawerNavigator } from 'react-navigation';
import { Button } from 'react-native-elements';
import Icon from 'react-native-vector-icons/FontAwesome'
import Entypo from 'react-native-vector-icons/Entypo'
import MaterialIcons from 'react-native-vector-icons/MaterialIcons'
import RNPickerSelect from 'react-native-picker-select';

class Switches extends Component {
    constructor() {
        super();
        this.state = {
            condition: false,
        }
    }
    render() {
        return (
            <View style={{ backgroundColor:'#E2E2E2',borderRadius:20 }}>
               <Switch
                    value={this.state.condition}
                    onTintColor={"#6AA84F"}
                    thumbTintColor={"#FFF"}
                    onValueChange={() => { this.setState({ condition: !this.state.condition }) }}
                />
            </View>
        );
    }
}

// define your styles
const styles = StyleSheet.create({
    label: { fontSize: 18, color: '#000', fontWeight: 'bold' },
    iconView: { flex: 1, paddingVertical: 40, marginLeft: 10 },
    inputView: {
        height: 45, marginTop: 10,
        // backgroundColor: '#DCD7D7',
        borderRadius: 5,
    },
    image: { width: width - 40, height: height / 4 },

});

//make this component available to the app
export default Switches;