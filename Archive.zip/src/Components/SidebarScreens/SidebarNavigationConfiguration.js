import React, { Component } from 'react';

import { StackNavigator } from 'react-navigation';

// import  component 
import RecycleBin from './View/RecycleBin.js';

// Auth navigator
const Sidebarnavigator = StackNavigator({
        RecycleBin: { screen: RecycleBin },

}, 
{
        initialRouteName: 'RecycleBin',
        headerMode: 'none',
      

    })



export default Sidebarnavigator;