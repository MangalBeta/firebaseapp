import React, { Component } from 'react';
import {
    View, Image, Dimensions, ScrollView, Button, StyleSheet, TouchableOpacity,
    KeyboardAvoidingView
} from 'react-native';
import { Text } from 'react-native-elements'

const { width, height } = Dimensions.get('window')
import { StackNavigator, DrawerNavigator } from 'react-navigation';
import Icon from 'react-native-vector-icons/FontAwesome'

// Import Images
import AppLogo from '../../../Assets/logo4x.png'
import MenuBar from '../../../Assets/menubar.png'
import CameraIcon from '../../../Assets/camera-48.png'
import DbIcon from '../../../Assets/database-48.png'
import BoxIcon from '../../../Assets/box-48.png'


import UploadImg from '../../../Assets/uploadicon2x.png'

const TabsArr = [BoxIcon, DbIcon, CameraIcon]

//Import component
import Header from '../../Common/Header'
import TabView from '../../Common/Tabs'

// create a component
class Home extends Component {
    static navigationOptions = ({ navigation }) => ({
        title: ``,
    });
    constructor() {
        super();
        this.state = {
            checked: false,
            indexItem: -1,
            active: false
        }
    }
    openDrawer() {
        this.props.navigate('DrawerOpen')
    }

    render() {
        console.log(this.props, "kljljljlkj")
        return (
            <View style={{ flex: 1 }}>
                <Header
                    rightIcon='bell'
                    leftIcon='bars'
                    color={'#009E0F'}
                    sidebar={true}
                    openScreen = {() => console.log('notification')}
                    navigateClick={() => this.props.navigation.navigate('DrawerOpen')} />
                                        <ScrollView >

                <View style={{ 
                    backgroundColor:'#D7CFCD',
                    paddingVertical: (height + 30) - height, paddingHorizontal:20}}>

                        <View style={styles.mainView}>
                            <TouchableOpacity onPress={() => this.props.navigation.navigate('FindAsset')}>

                                <View style={styles.cardView1}>
                                    <View style={styles.iconStyle}>
                                        <Icon size={42} name="search" color={'#ff6f20'} style={{alignSelf:'center'}}/>
                                    </View>
                                    <View style={styles.textLabel}>
                                        <Text h2 style={styles.headerText}>FIND </Text>
                                    </View>

                                </View>
                            </TouchableOpacity>

                            <TouchableOpacity onPress={() => this.props.navigation.navigate('List')}>
                                <View style={styles.cardView2}>
                                    <View style={styles.iconStyle}>
                                        <Icon size={36} name="file" color={'#5a6b71'} style={{alignSelf:'center'}}/>
                                    </View>
                                    <View style={styles.textLabel}>
                                        <Text h2 style={styles.headerText}>LIST </Text>
                                    </View>

                                </View>
                            </TouchableOpacity>
                            <TouchableOpacity onPress={() => this.props.navigation.navigate('CreateAsset')}>

                                <View style={styles.cardView3}>
                                    <View style={styles.iconStyle}>
                                        <Icon size={48} name="plus" color={'#f15b4e'} style={{alignSelf:'center'}} />
                                    </View>
                                    <View style={styles.textLabel}>
                                        <Text h2 style={styles.headerText}>CREATE </Text>
                                    </View>

                                </View>
                            </TouchableOpacity>

                        </View>

                </View>
                </ScrollView>


                    <TabView TabsArr = {TabsArr}/>


            </View>
        );
    }
}

// define your styles
const styles = StyleSheet.create({
    tabview: { flex: 1, padding: 10 },
    textLabel :{
         paddingLeft: 20 ,flex:0.7,
         fontFamily:'Helvetica Neue'
        //  marginLeft:10
    },
    mainView: {
        flex: 1,
        // paddingHorizontal: 20,
        justifyContent: 'center',
        // alignItems:'center'

        // paddingVertical:50
        // paddingVertical:20
    },
    headerText:{
    color: 'white' ,
    fontWeight: 'bold',
    alignSelf:'flex-start',
    fontFamily:'Helvetica Neue'


    },
    iconStyle: {
        justifyContent:'center',
        backgroundColor:'white',height:75,width:75,borderRadius:75/2,
    },
    image: { width: width - 40, height: height / 4 },
    cardView1: {
        flex: 1,
        backgroundColor: '#ff6f20',
        height: height / 5,
        marginBottom: 20,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        borderColor: "#ff6f20",
        borderWidth: 1,
        borderRadius: 2,
        // shadowOffset: { width: 0, height: 1, },
        // shadowColor: 'black',
        // shadowOpacity: 0.5,
        elevation: 5
    },
    cardView2: {
        backgroundColor: '#5a6b71',
        height: height / 5,
        flex: 1,
        marginBottom: 20,
        flexDirection: 'row',
        borderColor: "#5a6b71",
        borderWidth: 1,
        borderRadius: 2,
        // shadowOffset: { width: 0, height: 1, },
        // shadowColor: 'black',
        // shadowOpacity: 0.2,
        // elevation: 5,
        justifyContent: 'center',
        alignItems: 'center',

    },
    cardView3: {
        flex: 4,
        backgroundColor: '#f15b4e',
        height: height / 5,
        marginBottom: 20,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        borderColor: "#f15b4e",
        borderWidth: 1,
        borderRadius: 2,
        // shadowOffset: { width: 0, height: 1, },
        // shadowColor: 'black',
        // shadowOpacity: 0.2,
        // elevation: 5


    },
    tabText: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#fff',
        alignSelf: 'center'
    }
});

//make this component available to the app
export default Home;
