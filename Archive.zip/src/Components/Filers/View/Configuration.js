import React, { Component } from 'react';
import {
    View, Text, TextInput, Image, Dimensions, ScrollView, StyleSheet,
    KeyboardAvoidingView, Switch, Slider
} from 'react-native';
const { width, height } = Dimensions.get('window')
import { Button } from 'react-native-elements';
import Icon from 'react-native-vector-icons/FontAwesome'
import Entypo from 'react-native-vector-icons/Entypo'
import MaterialIcons from 'react-native-vector-icons/MaterialIcons'
import Dropdown from '../../Common/Dropdown'
import Switches from '../../Common/Switch'
import CameraIcon from '../../../Assets/camera-48.png'
import DbIcon from '../../../Assets/database-48.png'
import BoxIcon from '../../../Assets/box-48.png'

//Import component
import Header from '../../Common/Header'
import TabView from '../../Common/Tabs'
const TabsArr = [BoxIcon, DbIcon, CameraIcon]

// create a component
class ConfigurationScreen extends Component {
    constructor() {
        super();
        this.state = {
            quantity: 0,
            condition: true,
            value: 0,
            items: [
                {
                    label: 'Good',
                    value: 'Good',
                },
                {
                    label: 'Excellent',
                    value: 'Excellent',
                },
                {
                    label: 'Poor',
                    value: 'Poor',
                },
            ],
        }
    }
    render() {
        return (

            <View style={[styles.container, { flex: 1 }]}>
               <Header
                    leftIcon='home'
                    rightIcon='gear'
                    color={'white'}
                    sidebar={true}
                    navigateClick={() => this.props.navigation.navigate('Dashboard')} 
                    openScreen = {() => this.props.navigation.navigate('Filter')}
                    goBack={this.props.navigation.goBack} 
                    />
                <ScrollView style={{marginBottom:65,backgroundColor:'white'}}>
                    <View style={[{ flex: 1, padding: 20, backgroundColor: 'white' }]}>
                    <View style={{ marginBottom: 10 }}>
                            <Text style={{ marginBottom: 5 }}>Operating Unit</Text>
                            <Dropdown data={this.state.items} label={'Select a Unit'}/>
                        </View>
                        <View style={{ marginBottom: 10 }}>
                            <Text style={{ marginBottom: 5 }}>Plant</Text>
                            <Dropdown data={this.state.items} label={'Select a Plant'} />
                        </View>
                        <View style={{ marginBottom: 10 }}>
                            <Text style={{ marginBottom: 5 }}>Photo Scale Factor</Text>
                            <Slider
                                value={this.state.value}
                                onValueChange={value => this.setState({ value })}
                            />
                        </View>
                        <View style={{ marginBottom: 20 }}>
                            <Text style={{ marginBottom: 5 }}>Default New Asset Type</Text>
                            <Dropdown data={this.state.items} label={'Select a New Asset Type'} />
                        </View>
                        <View style={{ marginBottom: 10, flexDirection: 'row', justifyContent: 'space-between' }}>
                            <Text style={{}}>Upload Media</Text>
                            <Switches />
                        </View>
                        <View style={{ marginBottom: 10, flexDirection: 'row', justifyContent: 'space-between' }}>
                            <Text style={{}}>Lock Existing Records</Text>
                            <Switches />
                        </View>
                        <View style={{ marginBottom: 10, flexDirection: 'row', justifyContent: 'space-between' }}>
                            <Text style={{}}>Add New Assets To Package</Text>
                            <Switches />
                        </View>
                        <View style={{ marginBottom: 10, flexDirection: 'row', justifyContent: 'space-between' }}>
                            <Text style={{}}>Display Thumbnail Image</Text>
                            <Switches />
                        </View>




                    
                        <View style={{ marginBottom: 10 }}>
                            <Text style={{ marginBottom: 5 }}>Asset History Cache</Text>
                            <TextInput
                                placeholder="100"
                                underlineColorAndroid={"transparent"}
                                style={{ padding: 10, borderColor: '#828181', borderWidth: 2, }} editable={true} />
                        </View>
                        <View style={{ marginBottom: 10, flexDirection: 'row', justifyContent: 'space-between' }}>
                            <Text style={{}}>Class Selection Visible</Text>
                            <Switches />
                        </View>
                        <View style={{ marginBottom: 10, flexDirection: 'row', justifyContent: 'space-between' }}>
                            <Text style={{}}>Enable Free Children</Text>
                            <Switches />
                        </View>
                        <View style={{ marginBottom: 10, flexDirection: 'row', justifyContent: 'space-between' }}>
                            <Text style={{}}>Get Photos From Camera</Text>
                            <Switches />
                        </View>
                        <View
                            style={{
                                flexDirection: 'row',
                                flex: 0.1,
                                paddingHorizontal: 10,
                                justifyContent: 'center',
                                alignItems: 'center'
                            }}>
                            <View style={{ flex: 1, flexDirection: 'row', marginTop: 20 }}>
                                <View style={{ flex: 0.5 }}  >
                                    <Button
                                        title="Cancel"
                                        titleStyle={{
                                            fontWeight: "700", fontSize: 22,
                                            color: '#000'
                                        }}
                                        buttonStyle={{
                                            backgroundColor: "#E69138",
                                            width: width / 3,
                                            height: 45,
                                            paddingVertical: 5,
                                            borderColor: "#000",
                                            borderWidth: 2,
                                            borderRadius: 5,
                                            shadowOffset: { width: 10, height: 10, },
                                            shadowColor: 'black',
                                            shadowOpacity: 0.4,
                                            elevation: 5
                                        }}
                                    //containerStyle={{ marginTop: 20 }}
                                    />
                                </View>
                                <View style={{ flex: 0.5 }} >
                                    <Button
                                        title="Save"
                                        titleStyle={{ fontWeight: "700", fontSize: 22, color: '#000' }}
                                        buttonStyle={{
                                            backgroundColor: "#E69138",
                                            width: width / 3,
                                            height: 45,
                                            borderColor: "#000",
                                            paddingVertical: 5,

                                            borderWidth: 2,
                                            borderRadius: 5,
                                            shadowOffset: { width: 10, height: 15, },
                                            shadowColor: 'black',
                                            shadowOpacity: 0.7,
                                            elevation: 5
                                        }}
                                    // containerStyle={{ marginTop: 20 }}
                                    />
                                </View>
                            </View>

                        </View>
                        {/*</KeyboardAvoidingView>*/}
                    </View>
                </ScrollView>

                <TabView TabsArr={TabsArr} />

            </View>

        );
    }
}

// define your styles
const styles = StyleSheet.create({
    label: { fontSize: 18, color: '#000', fontWeight: 'bold' },
    iconView: { flex: 1, paddingVertical: 40, marginLeft: 10 },
    inputView: {
        height: 45, marginTop: 10,
        // backgroundColor: '#DCD7D7',
        borderRadius: 5,
    },
    image: { width: width - 40, height: height / 4 },

});

//make this component available to the app
export default ConfigurationScreen;