import { combineReducers } from "redux";

//import reducer
import AuthReducer from "./AuthReducer";

// Combine all reducer
export const makeRootReducer = () => {
    
	return combineReducers({
	        Auth : AuthReducer
	});
}

export default makeRootReducer;