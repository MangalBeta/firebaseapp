import React, { Component } from 'react';
import { View, Text, Image, StyleSheet,KeyboardAvoidingView } from 'react-native';
import Routes from './src/Routes'

import createStore from "./src/Store";
import { Provider } from "react-redux";

// Main App component
class App extends Component {
    renderApp(){
		const initialState = window.___INTITIAL_STATE__;
		const store = createStore(initialState);
		return (
			// <Provider store={store}>
                     <Routes />
			// </Provider>
		);
	}
    render() {
        return this.renderApp();
    }
}

export default App;
